#include <parm.h>
#include <stdio.h>

void run()
{
	BEGIN();
	PUTCHAR('P','r','o','j','e','t',' ','P','A','R','M');
	END();
}
